import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, User, ShoppingCart, LogOut, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [cartItemCount, setCartItemCount] = useState(0);
  const [memberInfo, setMemberInfo] = useState<any>(null);
  const { toast } = useToast();

  const mainNavItems = [
  { label: 'Home', href: '/' },
  { label: 'FAQs', href: '/faqs' },
  { label: 'League Rules', href: '/league-rules' },
  { label: 'Skill Level', href: '/skill-level' },
  { label: 'Tennis Clubs', href: '/tennis-clubs' },
  { label: 'Interest List', href: '/interest-list' },
  { label: 'Contact Us', href: '/contact-us' },
  { label: 'Skill Level', href: '/skill-level' },
  { label: 'View Previous Seasons', href: '/previous-seasons' },
  { label: 'Privacy Policy', href: '/privacy-policy' }];


  useEffect(() => {
    checkUserStatus();
  }, []);

  const checkUserStatus = async () => {
    try {
      const userResult = await window.ezsite.apis.getUserInfo();
      if (!userResult.error && userResult.data) {
        setUser(userResult.data);
        await loadMemberInfo(userResult.data);
      }
    } catch (error) {


      // User not logged in, this is expected
    } finally {setIsLoading(false);}
  };

  const loadMemberInfo = async (userData: any) => {
    try {
      const { data: memberData, error: memberError } = await window.ezsite.apis.tablePage(45643, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: "user_id",
          op: "Equal",
          value: userData.ID
        }]

      });

      if (!memberError && memberData?.List?.length > 0) {
        const member = memberData.List[0];
        setMemberInfo(member);
        await loadCartItemCount(member.id);
      }
    } catch (error) {
      console.error('Error loading member info:', error);
    }
  };

  const loadCartItemCount = async (memberId: number) => {
    try {
      const { data: cartData, error: cartError } = await window.ezsite.apis.tablePage(45648, {
        PageNo: 1,
        PageSize: 100,
        Filters: [
        {
          name: "member_id",
          op: "Equal",
          value: memberId
        }]

      });

      if (!cartError && cartData?.List) {
        const totalItems = cartData.List.reduce((sum: number, item: any) => sum + item.quantity, 0);
        setCartItemCount(totalItems);
      }
    } catch (error) {
      console.error('Error loading cart count:', error);
    }
  };

  const handleLogout = async () => {
    try {
      const result = await window.ezsite.apis.logout();
      if (result.error) {
        throw new Error(result.error);
      }

      setUser(null);
      setMemberInfo(null);
      setCartItemCount(0);
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out."
      });

      // Redirect to home page
      window.location.href = '/';
    } catch (error) {
      toast({
        title: "Logout Error",
        description: "An error occurred during logout.",
        variant: "destructive"
      });
    }
  };


  return (
    <header className="bg-gray-800 text-white">
      {/* Top Bar */}
      <div className="bg-gray-900">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-end space-x-6 text-sm">
            {!isLoading &&
            <>
                {user ?
              <>
                    <span className="flex items-center text-green-400">
                      <User className="w-4 h-4 mr-1" />
                      Welcome, {user.Name}
                    </span>
                    <a href="/order-history" className="hover:text-green-400 transition-colors flex items-center">
                      <Package className="w-4 h-4 mr-1" />
                      Orders
                    </a>
                    <button
                  onClick={handleLogout}
                  className="hover:text-green-400 transition-colors flex items-center">
                      <LogOut className="w-4 h-4 mr-1" />
                      Logout
                    </button>
                  </> :

              <>
                    <a href="/members/memberlogin" className="hover:text-green-400 transition-colors flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      Login
                    </a>
                    <a href="/registration" className="hover:text-green-400 transition-colors">
                      Register
                    </a>
                  </>
              }
                <a href="/cart" className="hover:text-green-400 transition-colors flex items-center relative">
                  <ShoppingCart className="w-4 h-4 mr-1" />
                  Cart
                </a>
              </>
            }
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-2xl md:text-3xl font-bold text-white">
              <a href="/" className="hover:text-green-400 transition-colors">
                Tennis League San Diego
              </a>
            </h1>
            <p className="text-sm text-gray-300 mt-1">A California Original Since 1990</p>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex space-x-6">
            {mainNavItems.map((item) =>
            <a
              key={item.label}
              href={item.href}
              className="text-white hover:text-green-400 transition-colors py-2 px-3 rounded">

                {item.label}
              </a>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="text-white hover:text-green-400">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-4 mt-8">
                  {/* User-specific links */}
                  {user &&
                  <div className="border-b pb-4 mb-4">
                      <a
                      href="/cart"
                      className="text-lg font-medium hover:text-green-600 transition-colors py-2 flex items-center"
                      onClick={() => setIsOpen(false)}>
                        <ShoppingCart className="w-5 h-5 mr-2" />
                        Cart
                        {cartItemCount > 0 &&
                      <span className="ml-2 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                            {cartItemCount > 99 ? '99+' : cartItemCount}
                          </span>
                      }
                      </a>
                      <a
                      href="/order-history"
                      className="text-lg font-medium hover:text-green-600 transition-colors py-2 flex items-center"
                      onClick={() => setIsOpen(false)}>
                        <Package className="w-5 h-5 mr-2" />
                        Order History
                      </a>
                    </div>
                  }
                  
                  {/* Main navigation items */}
                  {mainNavItems.map((item) =>
                  <a
                    key={item.label}
                    href={item.href}
                    className="text-lg font-medium hover:text-green-600 transition-colors py-2"
                    onClick={() => setIsOpen(false)}>

                      {item.label}
                    </a>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>);

};

export default Header;